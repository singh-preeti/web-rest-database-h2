insert into employees values('1','Sam','IT');
insert into employees values('2','Pam','IT');
insert into employees values('3','Hero','HR');
insert into employees values('4','Alice','IT');
insert into employees values('5','Bob','IT');