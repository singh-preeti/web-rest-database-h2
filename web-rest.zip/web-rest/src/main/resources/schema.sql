create table employees
(
   id varchar(255) not null,
   name varchar(255) not null, 
   dept varchar(255) not null,
   primary key(id)
);