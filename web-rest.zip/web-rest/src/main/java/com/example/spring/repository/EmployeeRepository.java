package com.example.spring.repository;

import java.util.List;

import com.example.spring.model.Employee;

public interface EmployeeRepository {

    List<Employee> getEmployeeList();
}
