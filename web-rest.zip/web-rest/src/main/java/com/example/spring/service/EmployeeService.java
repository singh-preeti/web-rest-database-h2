package com.example.spring.service;

import java.util.List;

import com.example.spring.model.Employee;

public interface EmployeeService {

    List<Employee> getEmployees();
}
